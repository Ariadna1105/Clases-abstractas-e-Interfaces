import java.util.Scanner;

public abstract class Jugador {

    public abstract void Correr();
    public abstract void PasarBalon();
    public abstract void HacerGol();

}
