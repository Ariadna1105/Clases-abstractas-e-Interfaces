public interface InterDelantero {

    public void Rematar();
    public  void HacerRegate();
    public void DefinirGol();

}
