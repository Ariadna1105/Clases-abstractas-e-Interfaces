public interface InterCentroCam {

    public void RecuperarBalon();
    public void CrearJuego();
    public void DarAsistencia();

}
