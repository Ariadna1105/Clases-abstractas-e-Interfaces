public interface InterDefensor {

    public void CortarPase();
    public void DespejarBalon();
    public void MarcarJugador();

}
