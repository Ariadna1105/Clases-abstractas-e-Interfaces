public interface InterPortero {

    public void AtajarBalon();
    public void DespejarCentro();
    public void SacarPorteria();

}
